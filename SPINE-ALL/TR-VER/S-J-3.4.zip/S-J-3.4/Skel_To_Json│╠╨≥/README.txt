Drag and drop two files(*.skel & *.atlas) onto this program. (Two * should be the same)
将两个文件(*.skel和*.atlas)拖拽到本程序上(两个*需要一样)
I will OVERRIDE *.json(result) and *.txt(features not supported by Dragonbones)
两个文件将会被覆盖:*.json(输出文件)和*.txt(龙骨不支持的特性)