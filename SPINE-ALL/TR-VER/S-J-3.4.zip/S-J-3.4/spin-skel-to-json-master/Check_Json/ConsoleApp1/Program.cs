﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Script.Serialization;
using Spine;
using BinToJson;


namespace BIN2JSON
{

    class Program
    {

        private static bool CHECK_JSON_FILE = false;

        // Change It as the Char Name.
        private static string boneName = "";

        static void Main(string[] args)
        {
            //#region Copy With Args
            Console.WriteLine("Spine Binary to Json Start.");

            string atlasPath = null;
            if (args.Length >= 2)
            {
                for (int i = 0; i < 2; ++i)
                {
                    if (args[i].EndsWith(".json"))
                        CHECK_JSON_FILE = true;
                    else if (args[i].EndsWith(".atlas"))
                        atlasPath = args[i];
                }
            }
            boneName = atlasPath.Substring(0, atlasPath.Length - 6);
            
            // Creat SkelData
            SkeletonData skeletonData;
            try
            {
                TextureLoader textureLoader = new DemoLoader();
                Atlas atlas = new Atlas(atlasPath, textureLoader);
                AtlasAttachmentLoader attachmentLoader = new AtlasAttachmentLoader(atlas);

                if (CHECK_JSON_FILE)
                {
                    SkeletonJson skeletonBinary = new SkeletonJson(attachmentLoader);
                    skeletonData = skeletonBinary.ReadSkeletonData(boneName + ".json");
                }
                else
                {
                    SkeletonBinary skeletonBinary = new SkeletonBinary(attachmentLoader);
                    skeletonData = skeletonBinary.ReadSkeletonData(boneName + ".skel");
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.ToString());
                Console.WriteLine("File Read Error.");
                return;
            }

            if (!CHECK_JSON_FILE)
            {
                // Test the SkelData.
                Console.WriteLine("The spine version: \t" + skeletonData.Version);
                Console.WriteLine("The bones name: \t" + skeletonData.Name);
                //Console.WriteLine("Find the Animation: \t" + skeletonData.FindAnimation("attack").Name);

                #region JSON File Create
                // Takes the skeletonData and converts it into a serializable object
                Dictionary<string, object> jsonFile = SkelDataConverter.FromSkeletonData(skeletonData);

                //convert object to json string for storing
                JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                jsonSerializer.MaxJsonLength = Int32.MaxValue;
                string json = jsonSerializer.Serialize(jsonFile);
                File.WriteAllText(boneName + ".json", json);
                #endregion
                Console.WriteLine("Json File Create Successfully.");
            }
        }
    }

    // False Class
    class DemoLoader : TextureLoader
    {
        public void Load(AtlasPage page, string path)
        {
            //throw new NotImplementedException();
            return;
        }

        public void Unload(object texture)
        {
            //throw new NotImplementedException();
            return;
        }
    }
}
