# SpineBinary2Json

* 一直想用碧蓝航线中的小人素材，通过龙骨来制作沙雕动画；
* Unity Spine 大多是.skel格式要自己转换；
* 直到找到这个库`https://github.com/PeterMoras/SpineBinaryConverter`才有了些许突破；
* 骨骼的位置还是有些问题；