[Chinese version 中文版](https://github.com/huix-oldcat/SpineBin2Json35/blob/master/Readme-zh-CN.md)

# SpineBin2Json35

License : GPL v3

Convert Spine binary format file **v3.5 (most 3.5.51)** to JSON format.

This program converts the file directly without the Spine runtime library.

Usage:

* Drag and drop two files(`*.skel` & `*.atlas`) onto this program.
* `Two *` should be `the same`
* Then the program will CREATE/**OVERRIDE** `*.json`(result) `*.txt`(features not supported by Dragonbones)

