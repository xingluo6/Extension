[English version 英文版](https://github.com/huix-oldcat/SpineBin2Json35/blob/master/Readme.md)

# SpineBin2Json35

许可证 : GPL v3

将Spine二进制导出文件 **v3.5 (最常见的是3.5.51)** 转换为JSON格式.

这个程序并不是基于Spine运行库的.

Usage:

* 将两个文件(`*.skel`和`*.atlas`)拖拽到本程序上
* 两个`*`需要一样
* 程序会创建/**覆盖**`*.json`(导出文件) `*.txt`(龙骨不支持的特性)
