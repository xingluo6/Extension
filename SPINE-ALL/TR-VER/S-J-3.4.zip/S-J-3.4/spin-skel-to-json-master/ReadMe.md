skel转json： SpineBin2Json35.exe ./test.atlas ./test.skel


校验Json格式是否正确: ConsoleApp1.exe ./test.atlas ./test.json