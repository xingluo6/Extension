# skel2json


## Usage example

```
dotnet build
dotnet run -- "c233_01.skel"
```
