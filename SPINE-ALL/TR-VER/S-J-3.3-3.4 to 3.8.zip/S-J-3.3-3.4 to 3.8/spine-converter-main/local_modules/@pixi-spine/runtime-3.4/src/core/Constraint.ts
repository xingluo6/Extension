/**
 * @public
 */
export abstract class ConstraintData {
  constructor(
    public name: string,
    public order: number,
    public skinRequired: boolean
  ) {}
}
