将 Spine 二进制格式文件 v3.5（大多数为 3.5.51）转换为 JSON 格式。

该程序直接转换文件，无需 Spine 运行时库。

用法：

将两个文件（& ）拖放到此程序上。*.skel*.atlas
Two *应该是the same
然后程序将 CREATE/OVERRIDE （result） （Dragonbones 不支持的功能）*.json*.txt