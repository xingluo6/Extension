import os
import subprocess
import json
import sys
import shutil
import re

def convert_spine_files(root_dir, jar_path, overwrite=False):
    # 收集所有JSON文件
    json_files = []
    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            if filename.lower().endswith('.json') and not filename.endswith("_38.json"):
                json_files.append(os.path.join(dirpath, filename))
    
    if not json_files:
        print(f"在目录 {root_dir} 中未找到JSON文件")
        return
    
    # 转换文件
    success_files = []  # 成功转换的文件
    failed_files = []   # 转换失败的文件
    replace_files = []  # 需要后续修改的文件路径
    
    for input_path in json_files:
        # 准备输出路径
        dir_name, file_name = os.path.split(input_path)
        base_name, ext = os.path.splitext(file_name)
        output_path = os.path.join(dir_name, f"{base_name}_38{ext}")
        
        # 备份原始文件（仅覆盖模式）
        backup_path = None
        if overwrite:
            backup_path = input_path + ".bak"
            try:
                shutil.copy2(input_path, backup_path)
                print(f"已创建备份: {backup_path}")
            except Exception as e:
                print(f"备份失败: {input_path}, 错误: {str(e)}")
                failed_files.append(input_path)
                continue
        
        # 执行转换命令
        cmd = [
            "java",
            "-cp", jar_path,
            "com.esotericsoftware.spine.JsonRollback",
            input_path,
            "3.8",
            output_path
        ]
        
        try:
            print(f"正在转换: {input_path}")
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            success_files.append(input_path)
            
            # 处理覆盖模式
            if overwrite:
                try:
                    os.remove(input_path)
                    os.rename(output_path, input_path)
                    replace_files.append(input_path)
                    print(f"已覆盖: {input_path}")
                except OSError as e:
                    print(f"文件覆盖失败: {input_path}, 错误: {str(e)}")
                    failed_files.append(input_path)
            else:
                replace_files.append(output_path)
                print(f"已生成: {output_path}")
                
        except subprocess.CalledProcessError as e:
            print(f"转换失败: {input_path}")
            print(f"错误信息: {e.stderr.strip()}")
            failed_files.append(input_path)
            
            # 恢复备份（如果存在）
            if overwrite and backup_path and os.path.exists(backup_path):
                try:
                    shutil.move(backup_path, input_path)
                    print(f"已恢复备份: {input_path}")
                except Exception as restore_error:
                    print(f"恢复备份失败: {input_path}, 错误: {str(restore_error)}")
    
    # 修改Spine版本信息 - 增强匹配逻辑
    modified_count = 0
    for file_path in replace_files:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 使用正则表达式匹配更灵活的版本格式
            pattern = r'("spine"\s*:\s*)"(3\.8-from-[^"]+)"'
            match = re.search(pattern, content)
            
            if match:
                # 替换为3.8.99版本
                new_content = content.replace(match.group(0), f'{match.group(1)}"3.8.99"')
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                
                modified_count += 1
                print(f"已修改版本号: {file_path}")
            else:
                # 检查是否已经是3.8.99版本
                if "3.8.99" not in content:
                    print(f"未找到可替换的版本号: {file_path}")
                
        except (IOError, json.JSONDecodeError) as e:
            print(f"处理文件失败: {file_path}, 错误: {str(e)}")
    
    # 清理备份文件
    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            if filename.endswith(".bak"):
                try:
                    os.remove(os.path.join(dirpath, filename))
                except Exception:
                    pass
    
    # 打印总结报告
    print("\n" + "=" * 50)
    print(f"处理完成! 共处理 {len(json_files)} 个文件")
    print(f"成功转换: {len(success_files)} 个文件")
    print(f"失败转换: {len(failed_files)} 个文件")
    print(f"修改版本号: {modified_count} 个文件")
    
    if failed_files:
        print("\n失败文件列表:")
        for i, file_path in enumerate(failed_files, 1):
            print(f"{i}. {file_path}")
    
    print("=" * 50)

if __name__ == "__main__":
    # 自动获取JAR文件路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    jar_path = os.path.join(script_dir, "spine-skeletonviewer-4.2.jar")
    
    if not os.path.exists(jar_path):
        print(f"错误: 未找到 spine-skeletonviewer-4.2.jar")
        print("请确保JAR文件与脚本在同一目录")
        sys.exit(1)
    
    # 用户输入
    target_dir = input("请输入要处理的根目录路径: ").strip()
    if not os.path.isdir(target_dir):
        print(f"错误: 目录不存在 - {target_dir}")
        sys.exit(1)
    
    mode = input("请选择模式 (1-普通模式, 2-覆盖模式): ").strip()
    overwrite = mode == "2"
    
    print(f"\n开始处理目录: {target_dir}")
    print(f"模式: {'覆盖模式' if overwrite else '普通模式'}")
    print(f"使用JAR: {jar_path}")
    
    convert_spine_files(target_dir, jar_path, overwrite)